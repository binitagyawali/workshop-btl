
    <?php 
  include ("includes/db.php");
 if(isset($_GET['id']))
  {
    $delete_id =$_GET['id'];
    $delete_news ="DELETE FROM `news` WHERE news_id='$delete_id'";
    $run_news = mysqli_query($con,$delete_news);
    if($run_news)
    {
        echo "<script>alert('delete was done sucessfully')</script>";
        echo"<script>window.open('listnews.php','_self')</script>";
    }
    else
    {
        echo "<script>alert ('please try again')</script>";
    }
  }

 ?>