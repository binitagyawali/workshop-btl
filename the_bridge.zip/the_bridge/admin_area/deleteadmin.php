<?php 
include ("includes/db.php");
 if(isset($_GET['id']))
  {
    $delete_id =$_GET['id'];
    $delete_admin ="DELETE FROM `admin` WHERE admin_id='$delete_id'";
    $run_admin = mysqli_query($con,$delete_admin);
    if($run_admin)
    {
        echo "<script>alert('delete was done sucessfully')</script>";
        echo"<script>window.open('adminlist.php','_self')</script>";
    }
    else
    {
        echo "<script>alert ('please try again')</script>";
    }
  }

 ?>