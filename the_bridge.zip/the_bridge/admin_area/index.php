<?php 
  session_start();
   include("includes/db.php");
   
 ?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
  <link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
<center>
<div class="wrapper animated bounce">
  <h1>Admin Login</h1>
  
  
  <form method="post">
    <h2>Email</h2>
    <input type="email" placeholder="Enter your email" name="email"><br>
    <h2>Password</h2>
    <input type="password" placeholder="Password" name="password"><br><br>
    <input type="submit" value="Sign In" name="login">
   
  </form>

</div>
</center>

</body>
</html>
<?php 

   if(isset($_POST['login']))
   {
    $admin_email=$_POST['email'];
    $admin_pass = $_POST['password'];
    $get_admin = "SELECT * FROM `admin` WHERE admin_email='$admin_email' AND admin_password='$admin_pass'";
    $run_admin = mysqli_query($con,$get_admin);
    $check_admin = mysqli_fetch_array($run_admin);
    $email = $check_admin['admin_email'];
    $row_admin = mysqli_num_rows($run_admin);
    if($row_admin>0)
    {
      $_SESSION['admin_email'] = $email;
      echo "<script>window.open('dashboard.php','_self')</script>";

    }
    else
    {
      echo "<script>alert('email and password is incorret please type the correct password')</script>";
    }
   }


 ?>