<?php
	require_once 'class/common.class.php';
    require_once 'class/category.class.php';
    //require_once 'class/session.class.php';
    //sessionhelper::checklogin();
    require_once 'layout/header.php';
    

    $category = new category;
    if(isset($_GET['id']))
    {   		
    	$category->id = $_GET['id'];
				if(isset($_POST['submit']))
    			{
			    	$category->category_name = $_POST['category_name'];
			    	//$category->modified_by = $_SESSION['admin'];
			    	//$category->status = $_POST['status'];
			    	$ask = $category->updatecategory();
			    	if($ask==="Duplicate")
			    	{
			    		echo "<script>alert('Duplicate Entry')</script>";
			    	}
			    	else if($ask)
			    	{
			    		echo "<script>alert('Updated Sucessfully')</script>";
			    	}
			    	else
			    	{
			    		echo "<script>alert('Update Unsucessful')</script>";
			    	}
	    		}
    }
    $data = $category->selectcategorybyid();
?>


    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">           
        
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">UPDATE CATEGORY FORM</h1>
            </div>
        </div><!--/.row-->
                
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- <div class="panel-heading">Form Elements</div> -->
                    <div class="panel-body">
                        <div class="col-md-6">
                            <form role="form" method="post">
                            
                                <div class="form-group">
                                    <label>Category Name</label>
                                    <input type="text" class="form-control" name="category_name" value="<?php echo $data[0]->cat_title; ?>">                                
                                </div>
                                


                                <button type="submit" name="submit" class="btn btn-primary">Submit Button</button>

                            </div>
                        </form>
                    </div>
                </div>
            </div><!-- /.col-->
        </div><!-- /.row -->
        
    </div>