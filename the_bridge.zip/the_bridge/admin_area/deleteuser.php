<?php 
include ("includes/db.php");
 if(isset($_GET['id']))
  {
    $delete_id =$_GET['id'];
    $delete_user ="DELETE FROM `user` WHERE user_id='$delete_id'";
    $run_user = mysqli_query($con,$delete_user);
    if($run_user)
    {
        echo "<script>alert('delete was done sucessfully')</script>";
        echo"<script>window.open('listform.php','_self')</script>";
    }
    else
    {
        echo "<script>alert ('please try again')</script>";
    }
  }

 ?>