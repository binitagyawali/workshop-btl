<?php
require_once'class/common.class.php';
require_once'class/forms.class.php';
require_once'class/session.class.php';
sessionhelper::checklogin();
//require_once "layout/header.php";
$forms=new forms;
$error=[];

if (isset($_POST['submit']))
{
	if(isset($_POST['name'])&& !empty($_POST['name']))
        {
            $forms->name = $_POST['name'];
        }
        else
        {
            $error[0] = "Name field cannot be empty!!";
         } 
         if (isset($_POST['email']) && !empty($_POST['email']))
		{
			$forms->email = $_POST['email'];
		}
		else 
		{
			$err[0] = "email cannot be entered"; 
		}
		
		if (isset($_POST['phone']) && !empty($_POST['phone']))
		{
			$forms->phone = $_POST['phone'];
		}
		else{
			$err[0] = "phone no cannot be empty";
		}
		if(isset($_POST['company_name'])&& !empty($_POST['company_name']))
		{
			$forms->company_name=$_POST['company_name'];
		}
		else
		{
			$err[0] ="name field cannot be empty";
		}
		if(isset($_POST['subject'])&& !empty($_POST['subject']))
		{
			$forms->subject=$_POST['subject'];
		}
		else
		{
			$err[0] ="subject field cannot be empty";
		}
		if(isset($_POST['message'])&& !empty($_POST['message']))
		{
			$forms->message=$_POST['message'];
		}
		else
		{
			$err[0] ="message field cannot be empty";
		}
		if(isset($_POST['category_name'])&& !empty($_POST['category_name']))
		{
			$forms->category_name=$_POST['category_name'];
		}
		else
		{
			$err[0] ="message field cannot be empty";
		}

		if (count($error)==0)
		{
			$forms->name = $name;
			$forms->email = $email;
			$forms->phone = $phone;
			$forms->company_name = $company_name;
			$forms->subject = $subject;
			$forms->message = $message;
			$forms->category_name;
			$forms->created_by = $_SESSION['admin'];
			$date=date('Y-m-d H:i:s');
            $forms->created_at = $date;
            $ask = $admin->insertuser();

            if ($ask==1)
            {
                echo "<script>alert('inserted successfully')</script>";
            }
            else
            {
                echo "<script>alert('Failed to insert')</script>";
            }
        }
    

?>
	<!DOCTYPE html>
	<html>
	<head>
		<title></title>
	</head>
	<body>
	

		
		
				<h1>Forms</h1>

							
				         <form>
									<label>name</label>
									<input types="text" placeholder="Full Name" name="name">

									<label>Email</label>
									<input types="text" placeholder="Email" name="email">
								
																
							
									<label>phone</label>
									<input type="number" placeholder="number" name="phone">
								
								
	
								  <label>company_name</label>
								    <input type="text"
								       name="company_name">
							

		
									<label>subject</label>
									<input type="text" placeholder="subject" name="subject">
			
				
									<label>message</label>
									<input type="text" placeholder="text" name="message">
			

		
                                    <label>Category</label>
                                    <select name="category_name">
                                    <?php
                                    $category=new category;
                                    $data = $category->listcategory();
                                    foreach ($data as  $value) {
                                    ?>
                                             <option><?php echo $value->category_name; ?> </option>
                                     <?php } ?>
                                     </select>
                                     
                                    

                               

                                
                                

                                <?php 
                                	foreach ($error as $err) {
                                    echo $err."<br>";
                                } ?>
								
								<input type="submit" name="submit"> 
								
						
								
									
								
						</form>
				
   </body>
   </html>