<?php
    require_once 'class/common.class.php';
    require_once 'class/category.class.php';
    require_once 'class/news.class.php';
    require_once 'class/session.class.php';
    sessionhelper::checklogin();
    require_once 'layout/header.php';
    $news = new news;
    if(isset($_GET['id']))
    {           
        $news->id = $_GET['id'];
                if(isset($_POST['submit']))
                {
                    $title= $_POST['title'];
                    $short= $_POST['short'];
                    $description= $_POST['desc'];
                    $category = $_POST['category'];
                    $modified_by= $_SESSION['admin'];
                    $news->title = $title;
                    $news->short_desc = $short;
                    $news->description = $description;
                    $news->category_name = $category;
                    $news->modified_by = $modified_by;
                    $news->status = $_POST['status'];
                    if (!empty($_FILES['image'])) 
                    {
                         $image =  $_FILES['image']['name'];
                         move_uploaded_file($_FILES['image']['tmp_name'], 'images/'.$image);
                         $news->image = $image;
                    }
                    $ask = $news->updatenews();
                    echo $ask;
                    if($ask==="Duplicate")
                    {
                        echo "<script>alert('Duplicate Entry')</script>";
                    }
                    else if($ask)
                    {
                        echo "<script>alert('Updated Sucessfully')</script>";
                    }
                    else
                    {
                        echo "<script>alert('Update Unsucessfully')</script>";
                    }
                }
    }
    $data = $news->selectnewsbyid();

?>


    <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">           
           
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">UPDATE NEWS</h1>
            </div>
        </div><!--/.row-->
                
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- <div class="panel-heading">Form Elements</div> -->
                    <div class="panel-body">
                        <div class="col-md-6">
                            <form role="form" method="post">
                            
                                <div class="form-group">
                                    <label>TITLE</label>
                                    <input type="text" class="form-control" name="title" value="<?php echo $data[0]->title; ?>">
                                </div>

                                <div class="form-group">
                                    <label>Short Description</label>
                                    <textarea type="text" class="form-control" name="short"><?php echo $data[0]->short_desc; ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea type="text" class="form-control" name="desc"><?php echo $data[0]->description; ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Status</label><br>
                                    <?php
                                    if($data[0]->status==0)
                                    { ?>
                                        Active:<input type="radio" name="status" value="1">
                                        Inactive<input type="radio" name="status" value="0" checked>
                                   <?php } 
                                    else
                                    { ?>
                                        Active:<input type="radio" name="status" value="1" checked>
                                        Inactive<input type="radio" name="status" value="0">
                                  <?php  } ?>
                                </div>

                                    <div class="form-group">
                                    <label>Category</label>
                                    <select name="category">
                                    <?php
                                    $category=new category;
                                    $data = $category->listcategory();
                                    foreach ($data as $value) {
                                    ?>
                                             <option><?php echo $value->category_name; ?> </option>
                                     <?php } ?> 
                                    </select> 
                                </div>

                                <div class="form-group">
                                    <label>Image</label>
                                    <input type="file" class="form-control" name="image"></textarea>
                                </div> 
                                <button type="submit" name="submit" class="btn btn-primary">Update</button>

                            </div>
                        </form>
                    </div>
                </div>
            </div><!-- /.col-->
        </div><!-- /.row -->

        
    </div>

    <?php
     require_once 'layout/footer.php';
    ?>
