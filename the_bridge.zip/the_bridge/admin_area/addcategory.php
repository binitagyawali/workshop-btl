<?php
    require_once 'class/common.class.php';
    require_once 'class/category.class.php';
   // require_once 'class/session.class.php';
   // sessionhelper::checklogin();
    require_once 'layout/header.php';
    $category=new category;
    $error=[];

    if (isset($_POST['submit']))
    {
        if(isset($_POST['name'])&& !empty($_POST['name']))
        {
            $name = $_POST['name'];
        }
        else
        {
            $error[0] = "Name Filed Cannot Be Empty!!";
        }

       

        if (count($error)==0)
        {
            $category->category_title = $name;
            $ask = $category->addcategory();
            if ($ask==1)
            {
                echo "<script>alert('inserted successfully')</script>";
            }
            else
            {
                echo "<script>alert('Failed to insert')</script>";
            }
        }
    }
?>

<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main"> 
        
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">CATEGORY FORM</h1>
            </div>
        </div><!--/.row-->
                
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- <div class="panel-heading">Form Elements</div> -->
                    <div class="panel-body">
                        <div class="col-md-6">
                            <form role="form" method="post">
                            
                                <div class="form-group">
                                    <label>Category Title</label>
                                    <input class="form-control" name="name" placeholder="Enter category name">
                                </div>

                              

<!--                                 <div class="form-group">
                                    <label>Email</label>
                                    <input class="form-control" type="email" name="email" placeholder="Enter your email">
                                </div>
                                                                
                                <div class="form-group">
                                    <label>Password</label>
                                    <input type="password" name="password" placeholder="Enter your password" class="form-control">
                                </div> -->

                            
                            

                                <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!-- /.col-->
        </div><!-- /.row -->
        
    </div>