<?php
    require_once 'class/common.class.php';
    require_once 'class/forms.class.php';
   // require_once 'class/admin.class.php';
   // require_once 'class/session.class.php';
   // sessionhelper::checklogin();
    require_once 'layout/header.php';
?>		
<script src="js/bootstrap-table.js"></script>

<link href="css/bootstrap-table.css" rel="stylesheet">


	 <div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">User List</h1>
			</div>
		</div><!--/.row-->
				
		
<!--/.row-->	
		<div class="row">
			<div class="col-md-12">
				<div class="panel panel-default">
					<!-- <div class="panel-heading">Basic Table</div> -->
					<div class="panel-body"> 
						<table data-toggle="table" border="2" width="600">
						    <thead>
						    <tr>
						        <th>ID</th>
						        <th>Name</th>
						        <th>Password</th>
						        <th>Email</th>
						        <th>Address</th>
						        <th>Location</th>
						        <th>update</th>
						        <th>Delete</th>
						    </tr>
						    </thead>
						    <tbody>
						    	<?php
						    		$user =new forms;
									$data = $user-> selectforms(); 
									foreach ($data as  $value) { ?> 
									<tr><td> <?php echo $value->user_id ; ?> </td>
									<td> <?php echo $value->user_name ; ?> </td>
								    <td><?php echo $value->user_pass; ?></td>
								    <td><?php echo $value->user_email; ?></td>
								    <td><?php echo $value->user_address; ?></td>
								    <td><?php echo $value->user_location; ?></td>

									
													
									   <?php 
													{
														echo "<td> <a  class='btn btn-primary' href='updateuser.php?id = $value->user_id'>Update</td>
														 
														   <td><a class='btn btn-danger' href='deleteuser.php?id=$value->user_id'>Delete</td>";
													}
													// else
													// {
													// 	echo "<a  class='btn btn-default' href='updatecategory.php'>Update</a>"."&nbsp" ; 
													// 	echo "<a class='btn btn-default' href='deletecategory.php'>Delete</a>";
													// }
											?>
										  
									<!-- <td> <?php// echo $value->password ; ?> </td>
									<td> -->  </tr>
									<?php } ?> 
									</tbody>
						   
						  <!--   </thead> -->
						</table>
					</div>
				</div>
			</div>

		</div>	
		
		
	</div>