<?php 
include ("includes/db.php");
 if(isset($_GET['id']))
  {
    $delete_id =$_GET['id'];
    $delete_cat ="DELETE FROM `category` WHERE cat_id='$delete_id'";
    $run_cat = mysqli_query($con,$delete_cat);
    if($run_cat)
    {
        echo "<script>alert('delete was done sucessfully')</script>";
        echo"<script>window.open('categorylist.php','_self')</script>";
    }
    else
    {
        echo "<script>alert ('please try again')</script>";
    }
  }

 ?>