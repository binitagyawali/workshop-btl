<?php
 class forms extends common{
 	public $user_name,$user_pass,$user_address,$user_location,$user_email;

 	public function selectforms()
 	{
 		$sql = "select * from user";
 		$data= $this->select($sql);
 		return $data;
 	}

 	public function selectformsbyid()
 	{
 		$sql = "select * from tbl_forms where id = '$this->id' ";
 		return $this->select($sql);
 	}

 	public function insertforms()
 	{
        
 		$sql = "insert into tbl_forms(name,email,phone,company_name,subject,message,category_name,created_by,created_at) values('$this->name','$this->email','$this->phone','$this->company_name','$this->subject','$this->message','$this->category_name','$this->created_by','$this->created_at') ";
 	
 		return $this->insert($sql);
 	}

 	

 	public function deletenews()
 	{
 		$sql = "delete from tbl_news where id = '$this->id' ";
 		return $this->delete($sql);
 	}

 	public function updatenews()
 	{

 		$date = date('Y-m-d H:i:s');
 		if(!empty($this->image))
 		{
 			$sql = "update tbl_news set title = '$this->title',category_name = '$this->category_name',short_desc = '$this->short_desc',description = '$this->description',image = '$this->image',modified_by = '$this->modified_by',modified_at = '$date',status = '$this->status' where id='$this->id'";
 		}
	 	else	
	 	{
	 		$sql = "update tbl_news set title = '$this->title',category_name = '$this->category_name',short_desc = '$this->short_desc',description = '$this->description',modified_by = '$this->modified_by',modified_at = '$date',status = '$this->status' where id='$this->id'";
	 	}
	 	return $this->update($sql);
	 }


}
?>