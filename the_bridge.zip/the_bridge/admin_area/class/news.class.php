<?php
 class news extends common{
 	public $news_id,$news_title,$short_desc,$description,$category_id,$image;

 	public function selectnews()
 	{
 		$sql = "select * from news";
 		$data= $this->select($sql);
 		return $data;
 	}

 	public function selectnewsbyid()
 	{
 		$sql = "select * from tbl_news where id = '$this->id' ";
 		return $this->select($sql);
 	}

 	public function insertnews()
 	{

 		$sql = "insert into news(news_title,category_id,short_desc,description,image) values('$this->title','$this->category_name','$this->short_desc','$this->description','$this->image') ";
 		
 	         return $this->insert($sql);
 	}

 	public function insertwithoutimg()
 	{
 		 $sql = "insert into news(news_title,category_name,short_desc,description) values('$this->title','$this->category_name','$this->short_desc','$this->description') ";
 		return $this->insert($sql);
 	}

 	public function deletenews()
 	{
 		$sql = "delete from tbl_news where id = '$this->id' ";
 		return $this->delete($sql);
 	}

 	public function updatenews()
 	{

 		$date = date('Y-m-d H:i:s');
 		if(!empty($this->image))
 		{
 			$sql = "update tbl_news set title = '$this->title',category_name = '$this->category_name',short_desc = '$this->short_desc',description = '$this->description',image = '$this->image',modified_by = '$this->modified_by',modified_at = '$date',status = '$this->status' where id='$this->id'";
 		}
	 	else	
	 	{
	 		$sql = "update tbl_news set title = '$this->title',category_name = '$this->category_name',short_desc = '$this->short_desc',description = '$this->description',modified_by = '$this->modified_by',modified_at = '$date',status = '$this->status' where id='$this->id'";
	 	}
	 	return $this->update($sql);
	 }


}
?>