<?php
 class category extends common{
 	public $cat_id,$cat_title;

 	public function selectcategorybyid()
		{
			$sql = "select * from category where cat_id = '$this->id'";
			return $this->select($sql);
		}

 	public function addcategory()
 	{
 		$sql = "INSERT INTO category(cat_title) VALUES('$this->category_title') ";
 		return $this->insert($sql);
 	}

 	public function listcategory()
 	{
 		$sql = "select * from category";
 		return $this->select($sql);
 	}

 	public function updatecategory()
 	{
 		$date = date('Y-m-d H:i:s');
 		$sql = "update category set cat_title = '$this->category_name'  where cat_id = '$this->id' ";
 		return $this->update($sql);
 	}

 	public function deletecategory()
 	{
 		$sql = "delete from tbl_category where id = '$this->id' ";
 		return $this->delete($sql);
 	}

 }

 ?>