<?php
  require_once 'common.class.php';
	class admin extends common{
		public $admin_id,$admin_name,$admin_username,$admin_email,$admin_password,$phone;

		public function selectadminbyusername(){
			$sql="select * from admin where admin_username='$this->username'";
			return $this->select($sql);
		}
		public function selectadminbyid()
		{
			$sql = "select * from admin where admin_id = '$this->id'";
			return $this->select($sql);
		}
		public function insertuser()
		{
			//$date = date('Y-m-d H:i:s');
			$sql = "insert into admin(admin_name,admin_username,admin_email,admin_password,phone)values('$this->name','$this->username','$this->email','$this->password','$this->phone') ";
			return $this->insert($sql);
		}
		public function selectuser()
		{
			$sql= "select * from admin";
			return $this->select($sql);
		}
		public function deleteadmin()
		{
			$sql = "delete from admin where admin_id = '$this->id'";
			return $this->delete($sql);
		}
		public function updateadmin()
		{
			$sql = "update admin set admin_name= '$this->name',admn_username = '$this->username', admin_email = '$this->email',phone='$this->phone' where admin_id = '$this->id'";
			return $this->update($sql);
		}
		public function updatelastlogin()
		{
			// if(isset($this->password) && empty($this->))
			$sql = "update tbl_admin set last_login = '$this->last_login' where username = '$this->username'";
			$this->update($sql);
		}
		public function updateadminwithpassword()
		{
			$sql = "update tbl_admin set name= '$this->name',username = '$this->username', email = '$this->email', phone='$this->phone', password = '$this->password' where id = '$this->id'";
			return $this->update($sql);
		}
	}
/*	// for procceding with image
	$image_name = $_FILES['image']['temp_name'];
	move_uploaded_file($_FILES['image']['name'], "layout/".$image_name);
	.......*/
?>

<!-- <form enctype="multipart/form-data" >
	<input type="file" name="image">
</form> -->
