<?php
	require_once 'class/common.class.php';
	require_once 'class/admin.class.php';
//	require_once 'class/session.class.php';
//    sessionhelper::checklogin();
	require_once 'layout/header.php';
	$admin=new admin;
	$err=[];
	if(isset($_POST['submit']))

		if(isset($_POST['name'])&& !empty($_POST['name']))
		{
			$admin->name=$_POST['name'];
		}
		else
		{
			$err[0] ="name field cannot be empty";
		}

		if(isset($_POST['username'])&& !empty($_POST['username']))
		{
			$admin->username = $_POST['username'];
		}
		else
		{
			$err[0] = "username must be entered";
		}
		if (isset($_POST['email']) && !empty($_POST['email']))
		{
			$admin->email = $_POST['email'];
		}
		else 
		{
			$err[4] = "email cannot be entered";
		}

		if (isset($_POST['password'])&& !empty($_POST['password']))
		{
			$admin->password = $_POST['password'];
		}
		else 
		{
			$err[4] = "password cannot be empty";
		}
		if (isset($_POST['phone'])&& !empty($_POST['phone']))
		{
			$admin->phone = $_POST['phone'];
		}
		else 
		{
			$err[4] = "phone no cannot be empty";
		}



if (count($err)==0)
{
	//$admin->salt=uniqid();
	//$admin->password = sha1($admin->salt.$password);

	$ask = $admin->insertuser();
	if($ask==1)
	{
		echo "<script>alert('inserted successfullly')</script>";
	}
	else
	{
		echo "<script>alert('failed to insert')</script>";	
	}
}


?>
<body>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
		<form method="post">
		Name:<input type="text" name="name" placeholder="Enter name" class="form-control"><br><br>
		Username:<input type="text" name="username" placeholder="Enter username" class="form-control"><br><br>
		Email:<input type="email" name="email" placeholder="Enter email" class="form-control"><br><br>
		Phone:<input type="text" name="phone" placeholder="Enter phone no." class="form-control"><br><br>
		Password:<input type="password" name="password" placeholder="Enter password" class="form-control" ><br><br>
		<input type="submit" name="submit">

	</form>
	</div>
		
	</div><!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		!function ($) {
			$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
				$(this).find('em:first').toggleClass("glyphicon-minus");	  
			}); 
			$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
