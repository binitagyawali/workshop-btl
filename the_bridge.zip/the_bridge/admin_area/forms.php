<?php
require_once'class/common.class.php';
require_once'class/category.class.php';
require_once'class/session.class.php';
sessionhelper::checklogin();
require_once "layout/header.php";
$forms=new forms;
$error=[];

if (isset($_POST['submit']))
{
	if(isset($_POST['name'])&& !empty($_POST['name']))
        {
            $forms->name = $_POST['name'];
        }
        else
        {
            $error[0] = "Name field cannot be empty!!";
         } 
         if (isset($_POST['email']) && !empty($_POST['email']))
		{
			$forms->email = $_POST['email'];
		}
		else 
		{
			$err[4] = "email cannot be entered"; 
		}
		
		if (isset($_POST['phone']) && !empty($_POST['phone']))
		{
			$forms->phone = $_POST['phone'];
		}
		else{
			$err[4] = "phone no cannot be empty";
		}
		if(isset($_POST['company_name'])&& !empty($_POST['company_name']))
		{
			$forms->company_name=$_POST['company_name'];
		}
		else
		{
			$err[0] ="name field cannot be empty";
		}
		if(isset($_POST['subject'])&& !empty($_POST['subject']))
		{
			$forms->subject=$_POST['subject'];
		}
		else
		{
			$err[0] ="subject field cannot be empty";
		}
		if(isset($_POST['message'])&& !empty($_POST['message']))
		{
			$forms->message=$_POST['message'];
		}
		else
		{
			$err[0] ="message field cannot be empty";
		}
		if(isset($_POST['category_name'])&& !empty($_POST['category_name']))
		{
			$forms->category_name=$_POST['category_name'];
		}
		else
		{
			$err[0] ="message field cannot be empty";
		}

		if (count($error)==0)
		{
			$forms->name = $name;
			$forms->email = $email;
			$forms->phone = $phone;
			$forms->company_name = $company_name;
			$forms->subject = $subject;
			$forms->message = $message;
			$forms->category_name;
			$forms->created_by = $_SESSION['admin'];
			$date=date('Y-m-d H:i:s');
            $forms->created_at = $date;

            if ($ask==1)
            {
                echo "<script>alert('inserted successfully')</script>";
            }
            else
            {
                echo "<script>alert('Failed to insert')</script>";
            }

	      }      



		}



			 
			 



?>
<html>
<head>
	
</head>
	<body>	
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
				<li class="active">Icons</li>
			</ol>
		</div><!--/.row-->
		
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Forms</h1>
			</div>
		</div><!--/.row-->
				
		
		<div class="row">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading">Form Elements</div>
					<div class="panel-body">
						<div class="col-md-6">
							<form role="form">
							
								<div class="form-group">
									<label>name</label>
									<input class="form-control" placeholder="Full Name" name="name">
								</div>
								<div class="form-group">
									<label>Email</label>
									<input class="form-control" placeholder="Email" name="email">
								</div>
																
								<div class="form-group">
									<label>phone</label>
									<input type="number" class="form-control" placeholder="number" name="phone">
								</div>
								
								<div class="form-group ">
								  <label>company_name</label>
								    <input type="text"
								       name="company_name">
								</div>

								<div class="form-group">
									<label>subject</label>
									<input type="text" class="form-control" placeholder="subject" name="subject">
								</div>
								<div class="form-group">
									<label>message</label>
									<input type="text" class="form-control" placeholder="text" name="message">
								</div>

								<div class="form-group">
                                    <label>Category</label>
                                    <select name="category">
                                    <?php
                                    $category=new category;
                                    $data = $category->listcategory();
                                    foreach ($data as  $value) {
                                    ?>
                                             <option><?php echo $value->category_name; ?> </option>
                                     <?php } ?>
                                     </select>
                                     </div>
<div class="form-group">
                                    <label>Category</label>
                                    <select name="category">
                                    <?php
                                    $category=new category;
                                    $data = $category->listcategory();
                                    foreach ($data as  $value) {
                                    ?>
                                             <option><?php echo $value->category_name; ?> </option>
                                     <?php } ?>

                                <div class="form-group">
                                    <label>Status</label><br>
                                    Active<input type="radio"  name="status" value="1">
                                    Inactive<input type="radio"  name="status" value="0">
                                </div>

                                <div class="form-group">
                                    <label>Short Description</label>
                                    <textarea class="form-control" name="short" rows="5" placeholder="Enter Short Description"></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" name="desc" rows="20" placeholder="Enter Description"></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Image</label>
                                    <input type="file" class="form-control" name="image">
                                </div>

                                <?php 
                                	foreach ($error as $err) {
                                    echo $err."<br>";
                                } ?>
								
								<button type="submit" class="btn btn-primary">Login     </button> <br>
								
								<label>Validation</label>
								<div class="form-group has-success">
									<input class="form-control" placeholder="Success">
								</div>
								<div class="form-group has-warning">
									<input class="form-control" placeholder="Warning">
								</div>
								<div class="form-group has-error">
									<input class="form-control" placeholder="Error">
								</div>
							</form>
								
							</div>
						
								
						</form>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
	</div><!--/.main-->

	<script src="js/jquery-1.11.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/chart.min.js"></script>
	<script src="js/chart-data.js"></script>
	<script src="js/easypiechart.js"></script>
	<script src="js/easypiechart-data.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script>
		!function ($) {
			$(document).on("click","ul.nav li.parent > a > span.icon", function(){		  
				$(this).find('em:first').toggleClass("glyphicon-minus");	  
			}); 
			$(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
		}(window.jQuery);

		$(window).on('resize', function () {
		  if ($(window).width() > 768) $('#sidebar-collapse').collapse('show')
		})
		$(window).on('resize', function () {
		  if ($(window).width() <= 767) $('#sidebar-collapse').collapse('hide')
		})
	</script>	
</body>

</html>
