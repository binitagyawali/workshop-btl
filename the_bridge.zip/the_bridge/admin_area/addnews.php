<?php
    require_once 'class/common.class.php';
    require_once 'class/news.class.php';
    require_once 'class/category.class.php';
   // require_once 'class/session.class.php';
   // sessionhelper::checklogin();
  //  require_once 'layout/header.php';
    $news=new news;
    $error=[];


    if (isset($_POST['submit']))
    {
        //$this->con->real_escape_string($_GET['id']);
        
        if (isset($_POST['title'])&& !empty($_POST['title'])) {
            $title = $news->escapestring($_POST['title']);
            
        }
        else
        {
            $error[0] = "Title Must Be Provided";
        }
        if (isset($_POST['category'])&& !empty($_POST['category'])) {
            $category = $_POST['category'];
        }
        else
        {
            $error[0] = "Category name must be selected";
        }
        if (isset($_POST['short'])) {
            $short_desc = $_POST['short'];
        }
        if (isset($_POST['desc'])&& !empty($_POST['desc'])) {
            $description = $_POST['desc'];
        }
        else
        {
            $error[0] = "Description must be provide";
        }

      //  if (isset($_POST['status'])) 
       // {
        //    $status = $_POST['status'];
       // }
        

        if (count($error)==0)
        {
            $news->title = $title;
            $news->category_name = $category;
            $news->short_desc = $short_desc;
            $news->description = $description;
           // $news->status = $status;
          //  $news->created_by = $_SESSION['admin'];
           // $date=date('Y-m-d H:i:s');
           // $news->created_at = $date;
            if ($_FILES['image']['error']==0 && $_FILES['image']['size']!=0) 
            {            
                $image=$_FILES['image']['name'];
                move_uploaded_file($_FILES['image']['tmp_name'],'images/$image');
                $news->image = $image;
                $ask = $news->insertnews();
            }
            else
            {
                $ask = $news->insertwithoutimg();
            }
            
            if ($ask==1)
            {
                echo "<script>alert('inserted successfully')</script>";
            }
            else
            {
                echo "<script>alert('Failed to insert')</script>";
            }
        }
    }
?>


<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">           
        
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">ADD NEWS</h1>
            </div>
        </div><!--/.row-->
                
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <!-- <div class="panel-heading">Form Elements</div> -->
                    <div class="panel-body">
                        <div class="col-md-6">
                            <form role="form" enctype="multipart/form-data" method="post">
                            
                                <div class="form-group">
                                    <label>Title</label>
                                    <input class="form-control" name="title" placeholder="News Title">
                                </div>

                                <div class="form-group">
                                    <label>Category</label>
                                    <select name="category">
                                    <?php
                                    $category=new category;
                                    $data = $category->listcategory();
                                    foreach ($data as  $value) {
                                    ?>
                                             <option name="<?php echo $cat_id;?>"> <?php echo $value->cat_title; ?> </option>
                                     <?php } ?> 
                                    </select> 
                                </div>

                              
                                <div class="form-group">
                                    <label>Short Description</label>
                                    <textarea class="form-control" name="short" rows="5" placeholder="Enter Short Description"></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Description</label>
                                    <textarea class="form-control" name="desc" rows="20" placeholder="Enter Description"></textarea>
                                </div>

                                <div class="form-group">
                                    <label>Image</label>
                                    <input type="file" class="form-control" name="image">
                                </div>

                              

                                <button type="submit" name="submit" class="btn btn-primary">Post News</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div><!-- /.col-->
        </div><!-- /.row -->
        
    </div>