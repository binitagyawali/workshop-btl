<?php 
 
   //session_start();
   require_once ('includes/db.php');
    
 ?>

<div>
	
	<form action=" " method="post" style="padding: 20px;">
		<table width="600" bgcolor="white" align="center" style="margin-right: 50px;">
		<tr>
			<td><h2 style="padding-left:  200px;">Login or Register</h2></td>
		</tr>

	 <tr>
		   <td><b style="padding-left: 100px;">Your Email:</b></td>
		   	<td height="100px"><input type = "text" name="email" placeholder="enter your Email"style="height:50px"></td>
   </tr>

	 <tr>
		<td style="height="100px" "><b style="padding-left: 100px;">password</b></td>
		<td><input type="password" name="pass" style="height:50px"></td>
	</tr>
	
     <tr>
		<td><center><input type="submit" name="login" value="Login"></center></td>
	</tr>
	</tr>
	
 </table>

	</form>
	
</div>

<?php 
    if(isset($_POST['login']))
    {
    	$user_email = $_POST['email'];
    	$user_pass =$_POST['pass'];
    	$sel_user = "select *from user where user_email='$user_email' AND user_pass='$user_pass'";
    	$run_user = mysqli_query($con,$sel_user);
    	$row_user = mysqli_fetch_array($run_user);
    	$user_email = $row_user['user_email'];

    	if(mysqli_num_rows($run_user)==0)
    	
    	{
    		echo "<script>alert('password or Email address is not correct,try again')</script>";
            
            echo"<script>window.open('new-profile.php?login.php','_self')</script>";

    	}
    	
    	else
    	{
    		//$_SESSION['user_email']=$user_email;
    		echo "<script>alert('password and email is correct')</script";

    		//echo "<script>window.open('payment.php','_self')</script>";
           // exit();
    	}


    }
 ?>





 ?>