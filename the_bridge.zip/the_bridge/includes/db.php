<?php 	


$con=mysqli_connect("localhost","root","","the_bridge");

if($con === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 ?>